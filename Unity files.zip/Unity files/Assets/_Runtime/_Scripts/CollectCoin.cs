﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Updates the score and plays a sound when you pickup a red or yellow coin.
// -----------------------------------------------------------------------------
public class CollectCoin : MonoBehaviour
{
     void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if(hit.collider.name=="Coin"||hit.collider.name=="Coin(Clone)")
        {
            Destroy(hit.gameObject);
            ScoreUpdate.coinScore+=1f;
            if(HealthUpdate.health<4)
            {
                HealthUpdate.health+=1;
            }
            AudioManagerScript.instance.Play("CoinPickup");
            if(PlayerMovement.speed<8f)
            {
                PlayerMovement.speed+=0.5f;
            }
        }
        
        if(hit.collider.name=="RedCoin"||hit.collider.name=="RedCoin(Clone)")
        {
            Destroy(hit.gameObject);
            ScoreUpdate.redCoinScore+=1f;
            if(HealthUpdate.health<4)
            {
                HealthUpdate.health+=1;
            }
            if(PlayerMovement.speed<8f)
            {
                PlayerMovement.speed+=0.8f;
            }
            AudioManagerScript.instance.Play("RedCoinPickup");
        }
      
    }
    
}
