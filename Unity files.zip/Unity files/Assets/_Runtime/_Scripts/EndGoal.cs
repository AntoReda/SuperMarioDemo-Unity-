﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Meant to set the static variable MarioWins which essentially dictates who won the race.
// -----------------------------------------------------------------------------
public class EndGoal : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if(gameObject!=null)
        {
            if(other.name=="Boo")
            {
                ScoreUpdate.MarioWins=false;
                Destroy(gameObject);
            }
            if(other.name=="Mario")
            {
                ScoreUpdate.MarioWins=true;
                Destroy(gameObject);
            }
        }
    }
}
