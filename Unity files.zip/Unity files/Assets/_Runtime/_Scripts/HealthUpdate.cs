﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Always updates the health of Mario
// -----------------------------------------------------------------------------
public class HealthUpdate : MonoBehaviour
{
    public Text healthText;
    public static int health=4;
    void Start()
    {
        healthText.text="Health: "+health;
    }

    void Update()
    {
        healthText.text="Health: "+health;
    }
}
