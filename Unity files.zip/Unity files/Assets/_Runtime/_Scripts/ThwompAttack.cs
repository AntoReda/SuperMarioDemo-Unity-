﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Hurts mario when he touches a thwomp as well as squishes him for 2 seconds.
// -----------------------------------------------------------------------------
public class ThwompAttack : MonoBehaviour
{
    public Transform Mario;
    void OnCollisionEnter(Collision other)
    {
        if(other.collider.name=="Mario")
        {
            //Damages mario and plays sounds.
            HealthUpdate.health=HealthUpdate.health-1;
            StartCoroutine(Squish());
            AudioManagerScript.instance.Play("Thwomp");
            AudioManagerScript.instance.Play("Hurt");
        }
    }
    IEnumerator Squish()
   {
       //makes mario y scale shorter for 2 seconds after getting hit by a thwomp.
       Mario.localScale=new Vector3(Mario.localScale.x,0.4f,Mario.localScale.z);
       yield return new WaitForSeconds(2f);
       Mario.localScale=new Vector3(Mario.localScale.x,1f,Mario.localScale.z);
   }
}
