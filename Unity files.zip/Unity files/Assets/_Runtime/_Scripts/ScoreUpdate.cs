﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: updates the score with the correct numbers on screen.
// -----------------------------------------------------------------------------
public class ScoreUpdate : MonoBehaviour
{
    public static float coinScore = 0f;
    public static float redCoinScore = 0f;
    public static bool MarioWins;
    public Text scoreText;
    
    void Start()
    {
        
        scoreText.text="X "+coinScore+"      X "+redCoinScore;

    }
    void FixedUpdate()
    {
        scoreText.text="X "+coinScore+"      X "+redCoinScore;
    }
}
