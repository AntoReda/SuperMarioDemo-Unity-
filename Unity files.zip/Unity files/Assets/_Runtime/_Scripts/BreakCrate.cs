﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Allows crates to be broken and drop a coin
// -----------------------------------------------------------------------------
public class BreakCrate : MonoBehaviour
{        
    public GameObject newCoin;

    void OnCollisionEnter(Collision other)
    {
        if(other.collider.name=="Crate")
        {
             AudioManagerScript.instance.Play("Box");
            Instantiate(newCoin, other.transform.position, Quaternion.identity);
            Destroy(other.gameObject);
        }
    }
    
}
