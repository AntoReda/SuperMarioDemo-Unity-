﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTrack : MonoBehaviour
{
    public Transform Player;
    public Rigidbody EnemyBody;
    private bool isTracking=false;
    private Vector3 PlayerPositionUpdate;
    public float speed=3f;
    void Update()
    {       
        if(isTracking)
        {
            //Rotates the enemy toward the player
            transform.LookAt(Player);
            transform.Rotate(0,180,0);
            //Moves toward the player and forbids jumps
            if(Player.position.y-gameObject.transform.position.y<0.5)
            {
                PlayerPositionUpdate = Vector3.MoveTowards(transform.position, Player.position, speed*Time.deltaTime);
                EnemyBody.MovePosition(PlayerPositionUpdate);
            }
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if(other.name=="Mario")
        {
            isTracking=true;
        }
       
    }
    void OnTriggerExit(Collider other)
    {
        if(other.name=="Mario")
        {
            isTracking=false;
        }
    }
    void OnCollisionEnter(Collision other)
    {
        //If bombs come in contact with mario damage him.
        if(other.collider.name=="Mario")
        {
            Destroy(gameObject);
            HealthUpdate.health-=1;
            AudioManagerScript.instance.Play("Explosion");
            AudioManagerScript.instance.Play("Hurt");
        }
    }
}
