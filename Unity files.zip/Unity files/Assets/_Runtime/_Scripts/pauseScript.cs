﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Displays the pause menu when you press Esc.
// -----------------------------------------------------------------------------
public class pauseScript : MonoBehaviour
{
   public static bool GameIsPaused = false;
    public GameObject PauseUi;
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(GameIsPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }
    public void Resume()
    {
        PauseUi.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    public void Pause()
    {
        PauseUi.SetActive(true);
        Time.timeScale = 0f;
        GameIsPaused = true;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
    public void RestartLevel()
    {
        Time.timeScale = 1f;
        GameIsPaused = false;
        ScoreUpdate.coinScore=0f;
        ScoreUpdate.redCoinScore=0f;
        HealthUpdate.health=4;
        PlayerMovement.speed=3.5f;
        SceneManager.LoadScene("BombombBattlefield");
    }
    public void quit()
    {
        Application.Quit();
    }
}
