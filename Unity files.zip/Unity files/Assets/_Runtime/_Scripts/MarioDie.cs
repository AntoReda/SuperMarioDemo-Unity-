﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Allows Mario to die if health=0;
// -----------------------------------------------------------------------------
public class MarioDie : MonoBehaviour
{
    public GameObject Sound;
    public GameObject LoseScreen;
    void Update()
    {
        if(HealthUpdate.health<=0)
        {
            
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            Destroy(Sound);
            LoseScreen.SetActive(true);
        }
    }
}
