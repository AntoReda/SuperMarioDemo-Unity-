﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: calculates if the thwomp should go down or not.
// -----------------------------------------------------------------------------
public class ThwompRange : MonoBehaviour
{
    public static bool isSlamming;
    void OnTriggerEnter(Collider other)
    {
        if(other.name=="Mario")
        {
            isSlamming=false;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if(other.name=="Mario")
        {
            isSlamming=false;
        }
    }
}
