﻿using UnityEngine.Audio;
using System;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: This script is used to access sounds while in other scripts and provides paramaters that can be 
//edited in the "Sounds" gameObject which has this script attached to it.
//Credit: Brackeys on youtube: https://www.youtube.com/c/Brackeys
// -----------------------------------------------------------------------------


public class AudioManagerScript : MonoBehaviour
{
    public Sound[] sounds;
    public static AudioManagerScript instance;
    void Awake()
    {
        foreach(Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip=s.clip;
            s.source.volume=s.volume;
            s.source.pitch=s.pitch;
            s.source.loop=s.loop;
        }
    }
    void OnEnable()
    {
        instance=this;
    }
    public void Play(string name)
    {
        Sound s =  Array.Find(sounds, sound=>sound.name==name);
        if(s==null)
        {
            return;
        }
        s.source.Play();
    }
}
