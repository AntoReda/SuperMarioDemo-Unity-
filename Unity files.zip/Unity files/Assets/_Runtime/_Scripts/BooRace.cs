﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Makes Boo go from checkpoint to checkpoint in the path I layed out
// -----------------------------------------------------------------------------
public class BooRace : MonoBehaviour
{
    public Transform CheckPoint;
    public Rigidbody EnemyBody;
    private Vector3 booPositionUpdate;
    public GameObject boo;
    public GameObject NextCheckpoint;

    public float speed=3f;   
    void Update()
    {       
        //Rotates the enemy toward the player
        boo.transform.LookAt(CheckPoint);
        //Moves toward the player
        booPositionUpdate = Vector3.MoveTowards(boo.transform.position, CheckPoint.position, speed*Time.deltaTime);
        EnemyBody.MovePosition(booPositionUpdate);
        
    }
    void OnTriggerEnter(Collider other)
    {
        if(other.name=="Boo")
        {
            //Activates the next checkPoint
            NextCheckpoint.SetActive(true);
        }
    }
}
