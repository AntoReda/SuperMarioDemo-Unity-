﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Win screen when star is picked up.
// -----------------------------------------------------------------------------
public class StarPickup : MonoBehaviour
{
    public GameObject WinScreen;

    void OnTriggerEnter(Collider other)
    {
        if(other.name=="Mario")
        {
            WinScreen.SetActive(true);
            Destroy(gameObject);
        }
    }
}
