﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Allows Mario to talk to Boo by left mouse click.
// -----------------------------------------------------------------------------
public class BooTalk : MonoBehaviour
{
    public GameObject boo;
    public Transform Player;
    public GameObject Checkpoint;
    public GameObject Speech;
    private bool isListening=false;
    void Update()
    {
        if(isListening)
        {
            boo.transform.LookAt(Player);
            if(Input.GetButtonDown("Fire1"))
            {
                //left mouseclick to activate the speechbox for Boo.
                Time.timeScale=0f;
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                Speech.SetActive(true);
            }
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if(other.name=="BooTalkRange")
        {
            isListening=true;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if(other.name=="BooTalkRange")
        {
            isListening=false;
        }
    }
    public void StartRace()
    {
        Checkpoint.SetActive(true);
        Speech.SetActive(false);
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    public void CancelRace()
    {
        Speech.SetActive(false);
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
}
