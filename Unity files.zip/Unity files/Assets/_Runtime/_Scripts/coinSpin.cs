﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: makes the red and yellow coins spin in place like the original game.
// -----------------------------------------------------------------------------
public class coinSpin : MonoBehaviour
{
    public GameObject coin;
    private float speed=4f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        coin.transform.Rotate(0f,speed,0);
       
    }
}
