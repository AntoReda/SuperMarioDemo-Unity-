﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Changes the Power up (health bar) by swapping sprites.
// -----------------------------------------------------------------------------
public class ChangePower : MonoBehaviour
{
    public GameObject blue;
    public GameObject green;
    public GameObject yellow;
    public GameObject red;
    public GameObject grey;
    void Update()
    {
        if(HealthUpdate.health==4)
        {
            blue.SetActive(true);
            green.SetActive(false);
        }
        if(HealthUpdate.health==3)
        {
            yellow.SetActive(false);            
            green.SetActive(true);
            blue.SetActive(false);
        }
        if(HealthUpdate.health==2)
        {
            red.SetActive(false);
            yellow.SetActive(true);
            green.SetActive(false);
        }
        if(HealthUpdate.health==1)
        {
            grey.SetActive(false);
            red.SetActive(true);
            yellow.SetActive(false);
        }
        if(HealthUpdate.health==0)
        {
            grey.SetActive(true);
            red.SetActive(false);
        }
    }
}
