﻿using UnityEngine.Audio;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Provides a template for the sound variables in the audio manager script.
//Credit: Brackeys on youtube: https://www.youtube.com/c/Brackeys
// -----------------------------------------------------------------------------
[System.Serializable]
public class Sound 
{
    public string name;
    public bool loop;
    public AudioClip clip;
    [Range(0f, 1f)]
    public float volume;
    [Range(0f, 1f)]
    public float pitch;
    [HideInInspector]
    public AudioSource source;  
}

