﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraNoClip : MonoBehaviour
{
    public GameObject player;
    public GameObject impact;
    private Vector3 PlayerPositionUpdate;
    private float range=30f;
    private float speed=5f;
    public Rigidbody CameraRb;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit hit;
        if(Physics.Raycast(player.transform.position, gameObject.transform.position, out hit, range))
        {
            PlayerPositionUpdate = Vector3.MoveTowards(transform.position, player.transform.position, speed*Time.deltaTime);
            CameraRb.MovePosition(PlayerPositionUpdate);
            Debug.Log(hit.transform.name);
        }
    }
}
