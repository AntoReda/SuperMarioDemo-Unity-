﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Activates Punch hitbox.
// -----------------------------------------------------------------------------
public class Punch : MonoBehaviour
{
    public GameObject handCollider;
    void Update()
    {
         if (Input.GetButtonDown("Fire1"))
         {
             //Punch with left mouseClick.
             StartCoroutine(ShowHand());
             AudioManagerScript.instance.Play("Hit");
         }
    }
    IEnumerator ShowHand()
   {
       //punch hitbox is active for 0.5 seconds.
       handCollider.SetActive(true);
       yield return new WaitForSeconds(0.5f);
       handCollider.SetActive(false);
   }
}
