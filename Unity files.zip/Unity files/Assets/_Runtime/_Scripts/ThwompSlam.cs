﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Thwomps always go back up regardless if mario is around but slams only when in proximity.
// -----------------------------------------------------------------------------
public class ThwompSlam : MonoBehaviour
{
    public Transform CheckPoint;
    public Rigidbody EnemyBody;
    private Vector3 thwompPositionUpdate;
    public GameObject thwomp;
    public GameObject CurrentCheckpoint;
    public GameObject NextCheckpoint;
    public Transform mario;
    private bool isSlamming=false;

    public float speed=3f;

    void Update()
    {       
        if(CurrentCheckpoint.name=="HighPos")
        {
            //if thwomp is on the ground, get back up.
            isSlamming=true;
        }
        if(isSlamming)
        {
            //Moves toward the ground and back up.
            thwompPositionUpdate = Vector3.MoveTowards(thwomp.transform.position, CheckPoint.position, speed*Time.deltaTime);
            EnemyBody.MovePosition(thwompPositionUpdate);
           
        }
        
    }
    void OnTriggerEnter(Collider other)
    {
        //resets the checkpoints (up and down)
        if(other.name=="Thwomp")
        {
            //Activates and deactivates the up and down paths for the thwomps.
            NextCheckpoint.SetActive(true);
            CurrentCheckpoint.SetActive(false);
            isSlamming=false;
        }
        if(other.name=="Mario")
        {
            isSlamming=true;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if(other.name=="Mario")
        {
            isSlamming=false;
        }
    }
    
}
