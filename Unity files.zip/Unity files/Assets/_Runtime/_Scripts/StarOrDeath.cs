﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: If mario wins the race generate a star else, kill him.
// -----------------------------------------------------------------------------
public class StarOrDeath : MonoBehaviour
{
    public GameObject boo;
    public Transform Player;
    public GameObject SpeechWin;
    public GameObject SpeechLose;
    public GameObject Star;
    private bool isListening=false;
    
    void Update()
    {
        if(isListening)
        {
            boo.transform.LookAt(Player);
            if(Input.GetButtonDown("Fire1"))
            {
                //talking to Boo
                Time.timeScale=0f;
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                //Shows correct dialogue.
                if(ScoreUpdate.MarioWins)
                {
                    SpeechWin.SetActive(true);
                }
                else{
                    SpeechLose.SetActive(true);
                }
            }
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if(other.name=="FinalTalk")
        {
            isListening=true;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if(other.name=="FinalTalk")
        {
            isListening=false;
        }
    }
    public void GetStar()
    {
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        Star.SetActive(true);
    }
    public void BooKills()
    {
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        HealthUpdate.health=0;
    }
    public void endButton()
    {
        //Closes dialogue window.
        if(ScoreUpdate.MarioWins)
        {
            SpeechWin.SetActive(false);
            GetStar();
        }
        else{
        SpeechLose.SetActive(false);
        BooKills();
        }
    }
}
