﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// ------------------------------------------------------------------------------
// Quiz
// Written by: Antonio Reda 40155615
// For COMP 376 – Fall 2021
//Description: Switches mario between animations (Idle, Running, attacking etc.)
// -----------------------------------------------------------------------------
public class PlayerAnimationScript : MonoBehaviour
{
    public static Animator animator;
    public static bool isJumping=false;
   
        void Start()
    {
        animator=GetComponent<Animator>();
    }
    void Update()
    {
        //If player is moving, play running animation
        if(PlayerMovement.movement.magnitude >= 0.1f)
        {
            animator.SetBool("Run", true);
           
        }
        else
        {
            //Player stops moving so play the idle animation.
            animator.SetBool("Run", false);
        }
        if(Input.GetButtonDown("Fire1"))
        {
            //Attack animation
            animator.SetTrigger("Punch");
        }
        if(Input.GetButton("Jump"))
        {
            animator.SetBool("Jump", true);
        }
    }
}
